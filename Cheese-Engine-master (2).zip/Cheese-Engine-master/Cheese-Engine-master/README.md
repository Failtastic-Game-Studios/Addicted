# Cheese-Engine
You are a drug dealer. You have a small family. You love text adventures. So you decide to play this game. Wow. 
So the actual game description: 
You have a small family. You are struggling to support your family. So you decide to become a drug dealer. 
This game takes you on a fun, exciting, and scary path through the balance of supporting a family, not getting caught, and growing/selling drugs. 

So what will be your choice? There's many, many choices to choose from and there's many different outcomes. 

So what do you think? Good concept? Would you buy it? Let me know in the discussion or by simply voting on it.
