#include "src\graphics\window.h"
#include "src\maths\vec2.h"
#include "main.h"

int main()
{
	using namespace cheese;
	using namespace graphics;
	using namespace maths;

	Window window("Cheese!", 1920, 1080, glfwGetPrimaryMonitor());
	glClearColor(0.2f, 0.3f, 0.8f, 1.0f);
	
	void shouldWindow(bool shouldWindow)
	{
		glfwDestroyWindow(m_Window);
		Window window("Cheese", 1280, 720, NULL);
	}
	
	GLuint vao;
	glGenVertexArrays(1, &vao);
	glBindVertexArray(vao);

	while (!window.closed())
	{
		window.clear();
		
		shouldWindow(shouldWindow);
		
		glBegin(GL_QUADS);
		glVertex2f(-0.1f, -0.1f);
		glVertex2f(-0.1f, 0.1f);
		glVertex2f(0.1f, 0.1f);
		glVertex2f(0.1f, -0.1f);
		glEnd();
		glDrawArrays(GL_ARRAY_BUFFER, 0, 6);
		window.update();
	}

	return 0;
}