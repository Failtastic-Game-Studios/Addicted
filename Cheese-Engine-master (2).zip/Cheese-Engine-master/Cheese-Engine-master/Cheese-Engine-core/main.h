#pragma once

bool shouldWindow();

static void goWindowed(bool shouldWindow);